def classFactory(iface):  # pylint: disable=invalid-name
    """Load EmergencyMapper class from file EmergencyMapper.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
"""
    from .Emergency_Mapper import EmergencyMapper
    return EmergencyMapper(iface)"""